
public class Operator {
	
	public int Operate() {
		return -1;
	}
	public int Operate(int num1, int num2) {
		return -1;
	}
	public int getOrder() {
		return 0;
	}
	
	public boolean isInteger() {
		return false;
	}
}
